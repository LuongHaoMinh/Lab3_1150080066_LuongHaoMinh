package week_03;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class frm_Menu extends JFrame {

    private JButton btn_rsa;
    private JButton btn_ecc;
    private JButton btn_rsaaes;
    private JButton btn_signature;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("LAB 3 - Mã hóa khóa công khai");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        JLabel lblTitle = new JLabel("LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        gbc.gridy = 0;
        mainPanel.add(lblTitle, gbc);

        JLabel lblSub = new JLabel("Chọn một bài để mở form tương ứng (bài 3.1 chạy RSADemo.java bằng Run File):");
        gbc.gridy = 1;
        mainPanel.add(lblSub, gbc);

        JPanel gridPanel = new JPanel(new GridLayout(2, 3, 12, 12));
        btn_rsa = new JButton("3.2 RSA (Swing)");
        btn_ecc = new JButton("3.3 ECC");
        btn_rsaaes = new JButton("3.4 RSA + AES");
        btn_signature = new JButton("3.5 Chữ ký ECDSA");
        btn_sql = new JButton("Kết nối SQL Server");
        btn_history = new JButton("Xem lịch sử");

        Dimension btnSize = new Dimension(200, 32);
        for (JButton btn : new JButton[]{btn_rsa, btn_ecc, btn_rsaaes, btn_signature, btn_sql, btn_history}) {
            btn.setPreferredSize(btnSize);
        }

        gridPanel.add(btn_rsa);
        gridPanel.add(btn_ecc);
        gridPanel.add(btn_rsaaes);
        gridPanel.add(btn_signature);
        gridPanel.add(btn_sql);
        gridPanel.add(btn_history);

        gbc.gridy = 2;
        gbc.insets = new Insets(10, 6, 6, 6);
        mainPanel.add(gridPanel, gbc);

        btn_rsa.addActionListener(e -> new frm_RSA().setVisible(true));
        btn_ecc.addActionListener(e -> new frm_ECC().setVisible(true));
        btn_rsaaes.addActionListener(e -> new frm_RSA_AES().setVisible(true));
        btn_signature.addActionListener(e -> new frm_ECC_Signature().setVisible(true));
        btn_sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));

        setContentPane(mainPanel);
        pack();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}